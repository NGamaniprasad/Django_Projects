# Django-Learning-Log
Learning log made in Django.
To run locally u will need to create a Python 3.5 virtualenv.
